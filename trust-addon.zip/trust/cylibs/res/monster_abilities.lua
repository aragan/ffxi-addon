-- Supplementary file to res/monster_abilities.lua

return T{
    [2667] = {id=2667,en="Mighty Guard",status=170},
}, {"id", "en", "status"}
