return {
    [83] = {id=83,en="Armor Break",status={149}},
    [85] = {id=85,en="Weapon Break",status={147}},
    [87] = {id=87,en="Full Break",status={146,147,148,149}},
    [115] = {id=115,en="Leg Sweep",status={10}},
    [181] = {id=181,en="Shell Crusher",status={149}},
}, {"id", "en", "status"}