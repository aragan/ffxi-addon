state.AutoFoodMode = M{['description'] = 'Auto Food Mode', 'Off', 'Auto'}
state.AutoFoodMode:set_description('Auto', "Okay, I'll eat when I'm hungry.")