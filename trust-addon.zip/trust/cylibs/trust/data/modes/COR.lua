-- Static modes file for COR
return {
    ["Rolling"]={
        ["autodispelmode"]="Off",
        ["autodebuffmode"]="Off",
        ["autopullmode"]="Off",
        ["autobuffmode"]="Off",
        ["autoskillchainmode"]="Off",
        ["combatmode"]="Off",
        ["autofoodmode"]="Off",
        ["autotrustsmode"]="Off",
        ["autoshootmode"]="Off",
    },
}