-- Static modes file for Pather role
return {
    ["Running"]={
        ["autodispelmode"]="Off",
        ["autofollowmode"]="Off",
        ["autosleepmode"]="Off",
        ["autoraisemode"]="Off",
        ["autobuffmode"]="Off",
        ["autosongmode"]="Off",
        ["autodebuffmode"]="Off",
        ["autofacemobmode"]="Off",
        ["autosilencemode"]="Off",
        ["autohealmode"]="Emergency",
        ["autoskillchainmode"]="Off",
        ["combatmode"]="Off",
        ["autofoodmode"]="Off",
        ["autobarspellmode"]="Off",
        ["autotrustsmode"]="Off",
        ["autopullmode"]="Off",
    },
}