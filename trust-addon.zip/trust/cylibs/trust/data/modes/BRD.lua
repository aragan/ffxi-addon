-- Static modes file for BRD
return {
    ["Singing"]={
        ["autodispelmode"]="Off",
        ["autosleepmode"]="Off",
        ["autoraisemode"]="Off",
        ["autobuffmode"]="Off",
        ["autodebuffmode"]="Off",
        ["autosilencemode"]="Off",
        ["autopullmode"]="Off",
        ["autohealmode"]="Emergency",
        ["autoskillchainmode"]="Off",
        ["combatmode"]="Off",
        ["autofoodmode"]="Off",
        ["autobarspellmode"]="Off",
        ["autotrustsmode"]="Off",
        ["autostatusremovalmode"]="Off",
    },
}
