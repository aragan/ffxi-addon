-- Settings file for NON
return {
    Version = 1,
    Default = {
        GambitSettings = {
            Default = L{

            },
            Gambits = L{
            }
        },
        PullSettings = {
            Abilities = L{
            },
            Targets = L{
            },
            Distance = 20
        },
    }
}