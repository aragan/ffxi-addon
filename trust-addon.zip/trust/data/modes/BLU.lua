-- Modes file for BLU
return {
    ["Default"]={
        ["autounloadondeathmode"]="Auto",
        ["autodispelmode"]="Off",
        ["subtrustsettingsmode"]="Default",
        ["automagicburstmode"]="Off",
        ["autofollowmode"]="Always",
        ["autobuffmode"]="Auto",
        ["autohealmode"]="Off",
        ["autoskillchainmode"]="Auto",
        ["autopullmode"]="Off",
        ["autoaftermathmode"]="Auto",
        ["skillchainprioritymode"]="Prefer",
        ["autoengagemode"]="Always",
        ["autotargetmode"]="Off",
        ["autotrustsmode"]="Off",
        ["autofacemobmode"]="Auto",
        ["skillchainpartnermode"]="Off",
        ["skillchaindelaymode"]="Off",
        ["maintrustsettingsmode"]="Default",
        ["combatmode"]="Off",
        ["engagemode"]="None",
        ["autofoodmode"]="Off",
        ["autoenmityreductionmode"]="Off",
        ["ipcmode"]="All",
    }
}