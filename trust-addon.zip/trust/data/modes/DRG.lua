-- Modes file for DRG
return {
    ["Default"]={
        ["autounloadondeathmode"]="Auto",
        ["skillchainpartnermode"]="Off",
        ["subtrustsettingsmode"]="Default",
        ["autofollowmode"]="Always",
        ["autobuffmode"]="Auto",
        ["automagicburstmode"]="Off",
        ["autoaftermathmode"]="Off",
        ["autoskillchainmode"]="Auto",
        ["skillchainprioritymode"]="Prefer",
        ["autoengagemode"]="Always",
        ["autotargetmode"]="Off",
        ["autotrustsmode"]="Off",
        ["maintrustsettingsmode"]="Default",
        ["autofacemobmode"]="Auto",
        ["skillchaindelaymode"]="Off",
        ["engagemode"]="None",
        ["autofoodmode"]="Off",
        ["combatmode"]="Off",
        ["autoenmityreductionmode"]="Off",
        ["ipcmode"]="All",
    }
}