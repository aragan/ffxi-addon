To run the installer:

1. If you don't already have the installer, download [TrustInstaller.zip](https://github.com/cyritegamestudios/trust/blob/main/Setup/TrustInstaller.zip) and unzip it to your Desktop.
2. Double-click on TrustInstaller.exe.
3. Follow the instructions in the installer to update to the latest version of Trust.
4. To check for updates, launch the Trust installer.
5. **If you'd like to get early access to updates, click the dropdown in the top right and select Alpha.**

**NOTE: do **NOT** put the installer inside of your Trust folder or updates won't be installed properly. Unzip TrustInstaller.zip to your Desktop or another location.**
